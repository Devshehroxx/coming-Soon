export const settings = {
  site: 'https://cannonball.littlesticks.dev',
  name: 'Little Sticks',
  title: 'Cannonball by Little Sticks | A splash page template',
  description: 'This is a simple splash page template built with Astro by Little Sticks',
}